﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp_SmartCookbook.models
{//to be removed
    public class RecipeInstruction
    {
        public int recipeId { get; set; }
        public string instruction { get; set; }
    }
}
